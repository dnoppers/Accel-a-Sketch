package mobiledev.unb.ca.accel_a_sketch;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class Draw extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;

    private AnimatedView mAnimatedView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Stop the screen from turning off due to perceived inactivity
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //Get the sensor data ready
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        mAnimatedView = new AnimatedView(this);
        //Set up the screen to behave like a small animation rather than a static View
        setContentView(mAnimatedView);


    }

    @Override
    protected void onResume() {
        super.onResume();

        //Wait for accelerometer input
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();

        //Stop grabbing accelerometer input while the app is inactive
        mSensorManager.unregisterListener(this);
    }

    //Needs to exist for proper implementation of the SensorEventListener
    //Currently unused
    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //Make sure to respond specifically to accelerometer input, as opposed to gyroscope
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            mAnimatedView.onSensorEvent(event);
        }
    }

    //It's not really an animated view. We should change the name to picture view or something.
    public class AnimatedView extends View {

        //originally: private static final int CIRCLE_RADIUS = 25;
        public int CIRCLE_RADIUS = 25; //size in pixels
        //Changed to allow for user-defined line thickness
        public int lineRadius = 15;
        //By having the pointer be thicker than the line, we ensure the pointer remains distinct

        //Playing around with this, but for now it doesn't really do much
        Display mdisp = getWindowManager().getDefaultDisplay();
        Point mdispSize = new Point();
        // mdisp.getSize(mdispSize);

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();

        private Paint mPaint;
        private int x = metrics.widthPixels;
        private int xPrev = x;
        private int y = metrics.heightPixels;
        private int yPrev = y;
        private int viewWidth;
        private int viewHeight;

        //Experimental portion
        private Bitmap mBitmap;
        private Path mPath;
        private Path pointerPath;
        private Paint linePaint;
        private Paint mBitmapPaint;
        private Canvas canvasTwo;

        public AnimatedView(Context context) {
            super(context);
            //Set default pointer and line draw colour
            mPaint = new Paint();
            mPaint.setColor(Color.BLACK);
            pointerPath = new Path();

            linePaint = new Paint();
            linePaint.setColor(Color.BLACK);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeJoin(Paint.Join.MITER);
            linePaint.setStrokeWidth(lineRadius);
            mPath = new Path();

            mBitmapPaint = new Paint(Paint.DITHER_FLAG);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            viewWidth = w;
            viewHeight = h;
            x = w/2;
            y = h/2;

            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            canvasTwo = new Canvas(mBitmap);

            mPath.reset();
            mPath.moveTo(x,y);
        }

        public void onSensorEvent (SensorEvent event) {
            xPrev = x;
            x = x - (int) event.values[0];
            yPrev = y;
            y = y + (int) event.values[1];

            mPath.quadTo(xPrev, yPrev, (x + xPrev)/2, (y + yPrev)/2);

            pointerPath.reset();
            pointerPath.addCircle(xPrev, yPrev, 30, Path.Direction.CW);

            //Makes sure that the ball doesn't go outside screen radius
            //no matter whether the screen is a mobile phone or a tablet
            if (x <= 0 + CIRCLE_RADIUS) {
                x = 0 + CIRCLE_RADIUS;
            }
            if (x >= viewWidth - CIRCLE_RADIUS) {
                x = viewWidth - CIRCLE_RADIUS;
            }
            if (y <= 0 + CIRCLE_RADIUS) {
                y = 0 + CIRCLE_RADIUS;
            }
            if (y >= viewHeight - CIRCLE_RADIUS) {
                y = viewHeight - CIRCLE_RADIUS;
            }

        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);
            canvas.drawPath(mPath, linePaint);
            canvas.drawPath(pointerPath, mPaint);

            canvas.drawCircle(x, y, CIRCLE_RADIUS, mPaint);
            //We need to call invalidate each time, so that the view continuously draws
            postInvalidate();
            //previously used just invalidate();
        }
    }
}